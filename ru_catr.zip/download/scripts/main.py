from model import BasicModelEn
from dataset import CocoCaptions
import torch

if __name__ == '__main__':
    dataset_train = CocoCaptions('./train2017', './annotations/captions_train2017.json')
    for image, target in dataset_train:
        print(image, target)
        break
    """
    model = BasicModelEn()
    
    text = 'On the picture we can see'
    encoded_input = model.tokenizer.encode_plus(text, return_tensors='pt')
    encoded_input['input_ids'] = torch.cat((torch.zeros_like(encoded_input['input_ids'][:, 0:1]) + model.spec_token_id, encoded_input['input_ids']), dim=-1)
    encoded_input['token_type_ids'] = torch.cat((torch.zeros_like(encoded_input['token_type_ids'][:, 0:1]), encoded_input['token_type_ids']), dim=-1)
    encoded_input['attention_mask'] = torch.cat((torch.zeros_like(encoded_input['attention_mask'][:, 0:1]) + 1, encoded_input['attention_mask']), dim=-1)
    output = model.decoder(**encoded_input)
    model.tokenizer.decode(encoded_input['input_ids'][0][1:])
    generated_sequence = model.decoder.generate(encoded_input['input_ids'], do_sample=True, num_beams=5)
    print(model.tokenizer.decode(generated_sequence[0]))
    """